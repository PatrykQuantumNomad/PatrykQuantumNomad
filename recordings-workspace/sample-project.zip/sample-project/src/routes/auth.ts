import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';

const router = Router();

// In-memory user store (demo only)
const users: Array<{ email: string; password: string }> = [];

router.post('/register', (req: Request, res: Response) => {
  const { email, password } = req.body;

  // Check if user already exists
  if (users.find((u) => u.email === email)) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  // TODO: hash password before storing
  users.push({ email, password });
  return res.status(201).json({ message: 'User registered successfully' });
});

router.post('/login', (req: Request, res: Response) => {
  const { email, password } = req.body;

  const user = users.find((u) => u.email === email && u.password === password);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: email, role: 'user' }, process.env.JWT_SECRET!, {
    expiresIn: '1h',
  });

  return res.json({ token });
});

export default router;
