import express from 'express';
import { authMiddleware } from './middleware';
import authRoutes from './routes/auth';

const app = express();
app.use(express.json());
app.use(authMiddleware);
app.use('/api/auth', authRoutes);

// TODO: add rate limiting middleware
app.get('/api/profile', (req, res) => {
  res.json({ message: 'Protected route', user: (req as any).user });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
