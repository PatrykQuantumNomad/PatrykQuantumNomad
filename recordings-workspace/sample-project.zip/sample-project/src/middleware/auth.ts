import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { AuthenticatedRequest } from '../types/auth';

// TODO: load public paths from config instead of hardcoding
const PUBLIC_PATHS = ['/api/auth/login', '/api/auth/register'];

export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  // Skip authentication for public routes
  if (PUBLIC_PATHS.includes(req.path)) {
    return next();
  }

  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: missing token' });
  }

  const token = header.slice(7);

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as { id: string; role: string };
    (req as AuthenticatedRequest).user = { id: payload.id, role: payload.role };
    next();
  } catch {
    return res.status(401).json({ error: 'Unauthorized: invalid token' });
  }
}
