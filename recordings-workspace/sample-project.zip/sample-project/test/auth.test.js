import { describe, it } from 'node:test';
import assert from 'node:assert';

describe('Auth validation', () => {
  it('should reject empty email', () => {
    const email = '';
    assert.strictEqual(email.length > 0, false);
  });

  it('should reject invalid email format', () => {
    const invalid = ['notanemail', 'missing@domain', '@no-local.com', 'spaces in@email.com'];
    for (const email of invalid) {
      assert.strictEqual(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), false);
    }
  });

  it('should accept valid email format', () => {
    const valid = ['user@example.com', 'name@domain.co', 'test.user@sub.domain.org'];
    for (const email of valid) {
      assert.strictEqual(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), true);
    }
  });

  it('should reject short passwords', () => {
    assert.strictEqual('short'.length >= 8, false);
    assert.strictEqual('1234567'.length >= 8, false);
  });

  it('should accept valid passwords', () => {
    assert.strictEqual('longpassword'.length >= 8, true);
    assert.strictEqual('12345678'.length >= 8, true);
  });
});
